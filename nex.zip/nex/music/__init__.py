# music app init
